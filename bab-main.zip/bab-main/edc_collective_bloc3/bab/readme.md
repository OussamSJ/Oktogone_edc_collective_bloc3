# Book a Book
## _Project description_

- Java 21
- Spring Boot 3.3.1
- Spring Web / Spring Data JPA / H2 Database

## To do

- Fix all issues identified by users
- Add unimplemented features required by users

You only have to work on the backend code. No frontend is required for this project.