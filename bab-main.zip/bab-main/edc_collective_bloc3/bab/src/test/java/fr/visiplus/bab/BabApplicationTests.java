package fr.visiplus.bab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabApplicationTests {

	@Test
	void contextLoads() {
	}

}
