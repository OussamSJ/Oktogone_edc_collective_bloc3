package fr.visiplus.bab.entities;

public enum BookStatus {

	AVAILABLE,
	BOOKED,
	BORROWED
	
}
